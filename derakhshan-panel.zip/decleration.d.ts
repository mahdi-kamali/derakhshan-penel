declare module "*.lottie";
