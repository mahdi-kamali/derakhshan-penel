import Icon from "@/components/UI/Icon/Icon";
import React from "react";

export default function Shade() {
  return <Icon icon='svg-spinners:blocks-wave' />;
}
