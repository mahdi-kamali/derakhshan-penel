import { CSSProperties, ReactElement } from "react";

import styles from "./styles.module.scss";

interface IProps extends CSSProperties {
  children: ReactElement[];
  header: string;
}

export default function Group(props: IProps) {
  const { children, header } = props;

  return (
    <div className={styles.group}>
      <div className={styles.header}>{header}</div>
      <div
        className={styles.body}
        style={props}>
        {children.map((child) => (
          <div className={styles.child} key={child.key}>{child}</div>
        ))}
      </div>
    </div>
  );
}
