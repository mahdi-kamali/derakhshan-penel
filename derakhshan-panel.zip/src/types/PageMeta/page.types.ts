export interface IPageMeta {
  title: string;
}
