"use client";
import PageContainer from "@/components/layout/PageContainer/PageContianer";
import { Grid } from "@/components/UI";

export default function Page() {
  return (
    <PageContainer title='پیشخوان'>
      <Grid>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel, vero
          delectus iste necessitatibus id suscipit aliquid ex illo asperiores
          nostrum, eligendi iure rerum cum, dolorum quidem. Repudiandae quas vel
          iure.
        </p>
      </Grid>
    </PageContainer>
  );
}
