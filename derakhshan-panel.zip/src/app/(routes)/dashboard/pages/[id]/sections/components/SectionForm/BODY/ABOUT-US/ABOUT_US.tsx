import MAIN from "./MAIN/MAIN";

export default { MAIN };
